from ._symplex_core import *

__doc__ = _symplex_core.__doc__
if hasattr(_symplex_core, "__all__"):
    __all__ = _symplex_core.__all__