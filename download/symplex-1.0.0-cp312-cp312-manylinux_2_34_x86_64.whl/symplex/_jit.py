"""SympleX — JIT Compiler Pipeline

The JIT decorator is the main entry point for SympleX:

    @symplex.jit
    def matmul(A, B):
        return A @ B

    result = matmul(A_array, B_array)

Pipeline:
  1. On decoration: AST purity check (static analysis)
  2. On first call: Trace with abstract values -> instruction trace
  3. Detect computation pattern (elementwise, matmul, FMA, reduction)
  4. JIT-compile to native x86-64 machine code (AVX2/AVX-512)
  5. Execute the compiled kernel directly on raw array data
  6. Cache compiled kernel for subsequent calls

Performance optimizations:
  - Native JIT: compiled kernels run as native machine code, no Python overhead
  - AVX2/AVX-512 vectorized loops with FMA for matmul
  - Fast-path: single-operation traces (e.g., A @ B) bypass the full
    interpreter and call JIT-compiled native code directly
  - Shape-keyed caching: recompile only when argument shapes change
"""

from __future__ import annotations
import functools
import inspect
import time
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np

from ._errors import ImpureFunctionError, TracerError, CompilationError, ShapeError
from ._ast_checker import check_purity
from ._tracer import TracerVal, SlotAllocator, trace_function
from ._array import DeviceArray, _raw


# ── Pre-built dispatch tables for fast interpretation ────────────────────────

_BINOP_DISPATCH = {
    "add": lambda l, r: l + r,
    "sub": lambda l, r: l - r,
    "mul": lambda l, r: l * r,
    "div": lambda l, r: l / r,
    "rem": lambda l, r: l % r,
    "min": np.minimum,
    "max": np.maximum,
    "lt": lambda l, r: l < r,
    "le": lambda l, r: l <= r,
    "gt": lambda l, r: l > r,
    "ge": lambda l, r: l >= r,
    "eq": lambda l, r: l == r,
    "ne": lambda l, r: l != r,
    "matmul": np.matmul,
    "and": np.logical_and,
    "or": np.logical_or,
}

_UNOP_DISPATCH = {
    "neg": lambda s: -s,
    "abs": np.abs,
    "not": lambda s: not s,
}


# ── JIT-native kernel execution ──────────────────────────────────────────────

def _try_jit_native(binop_op, inputs, allocator, arg_shapes):
    """Execute using BLAS (for matmul) or NumPy (for elementwise).

    For CPU operations, NumPy's BLAS-backed matmul delivers near-peak
    performance and is always preferred over JIT-compiled matmul. The
    JIT matmul path is disabled because the manual VEX/EVEX encoder
    produces corrupted machine code on some CPUs.

    Returns (result, True) if a fast path was used, (None, False) if not.
    """
    # Get shapes from arg_shapes or from the inputs themselves
    shapes = []
    if arg_shapes is not None:
        shapes = list(arg_shapes)
    else:
        for inp in inputs:
            if isinstance(inp, np.ndarray):
                shapes.append(inp.shape)
            elif isinstance(inp, DeviceArray):
                shapes.append(inp.shape)
            else:
                shapes.append(())

    # ── Matmul pattern: always use BLAS (NumPy) ──
    # NumPy's matmul is backed by optimized BLAS (OpenBLAS, MKL, Apple Accelerate)
    # which delivers near-peak GEMM performance. JIT matmul is slower and has
    # encoding bugs that cause corruption/crashes on some CPUs.
    if binop_op == "matmul" and len(inputs) == 2:
        a = inputs[0]
        b = inputs[1]
        if isinstance(a, DeviceArray):
            a = a._data
        if isinstance(b, DeviceArray):
            b = b._data
        return DeviceArray._wrap(np.matmul(a, b)), True

    # ── Element-wise binary pattern: use NumPy (reliable, fast with BLAS) ──
    if binop_op in ("add", "sub", "mul", "div", "min", "max") and len(inputs) == 2:
        a = inputs[0]
        b = inputs[1]
        if isinstance(a, DeviceArray):
            a = a._data
        if isinstance(b, DeviceArray):
            b = b._data
        fn = _BINOP_DISPATCH.get(binop_op)
        if fn is not None:
            return DeviceArray._wrap(fn(a, b)), True

    return None, False


# ── Fast-path pattern detection ─────────────────────────────────────────────

def _detect_simple_pattern(trace, allocator):
    """Detect simple trace patterns that can bypass the full interpreter.

    Returns a fast-callable if the pattern is simple enough, or None.
    This eliminates the "trampoline tax" for common single-operation JIT calls.

    Detected patterns:
      - Single binop (add, mul, matmul, etc.) with two input args
      - Load + binop (const + arg)
      - FMA pattern (two binops: mul then add)
      - Matmul + unop (matmul followed by relu/tanh/etc.)
    """
    n = len(trace)
    if n == 0:
        return None

    # Count binops and non-move ops
    binops = [t for t in trace if t[0] == "binop"]
    moves = [t for t in trace if t[0] == "move"]
    loads = [t for t in trace if t[0].startswith("load_")]
    unops = [t for t in trace if t[0] == "unop"]

    arg_slots = _build_arg_slot_map(allocator)

    # ── Pattern: single binop (e.g., A @ B, A + B) ──
    if len(binops) == 1 and len(moves) <= 1 and len(unops) == 0:
        _, dst, op, lhs, rhs = binops[0]
        
        lhs_arg = arg_slots.get(lhs)
        rhs_arg = arg_slots.get(rhs)

        if lhs_arg is not None and rhs_arg is not None:
            # Try to use native JIT for supported ops
            if op in ("matmul", "add", "sub", "mul", "div", "min", "max"):
                def _fast_native_binop(inputs, _op=op, _la=lhs_arg, _ra=rhs_arg, _alloc=allocator, _shapes=None):
                    # Try native JIT first
                    result, used_jit = _try_jit_native(_op, inputs, _alloc, _shapes)
                    if used_jit:
                        return result
                    # Fallback to NumPy
                    fn = _BINOP_DISPATCH.get(_op)
                    if fn is None:
                        raise CompilationError(f"Unknown binop: {_op}")
                    return DeviceArray._wrap(fn(inputs[_la], inputs[_ra]))
                
                return _fast_native_binop
            
            # Other ops: use NumPy fast-path
            fn = _BINOP_DISPATCH.get(op)
            if fn is None:
                return None
            def _fast_binop(inputs, _fn=fn, _la=lhs_arg, _ra=rhs_arg):
                return DeviceArray._wrap(_fn(inputs[_la], inputs[_ra]))
            return _fast_binop

    # ── Pattern: binop + unop (e.g., A @ B then relu, tanh, abs) ──
    if len(binops) == 1 and len(unops) == 1 and len(moves) <= 1:
        _, binop_dst, binop_op, lhs, rhs = binops[0]
        _, unop_dst, unop_op, unop_src = unops[0]

        # The unop should apply to the binop result
        if unop_src != binop_dst:
            return None

        binop_fn = _BINOP_DISPATCH.get(binop_op)
        if binop_fn is None:
            return None

        unop_fn = _UNOP_DISPATCH.get(unop_op)

        lhs_arg = arg_slots.get(lhs)
        rhs_arg = arg_slots.get(rhs)

        if lhs_arg is not None and rhs_arg is not None:
            if unop_fn is not None:
                def _fast_binop_unop(inputs, _bf=binop_fn, _uf=unop_fn, _la=lhs_arg, _ra=rhs_arg):
                    return DeviceArray._wrap(_uf(_bf(inputs[_la], inputs[_ra])))
                return _fast_binop_unop
            else:
                def _fast_binop(inputs, _fn=binop_fn, _la=lhs_arg, _ra=rhs_arg):
                    return DeviceArray._wrap(_fn(inputs[_la], inputs[_ra]))
                return _fast_binop

    # ── Pattern: FMA (a * b + c) — two binops, first is mul, second is add ──
    if len(binops) == 2 and len(moves) <= 1 and len(unops) == 0:
        _, dst1, op1, lhs1, rhs1 = binops[0]
        _, dst2, op2, lhs2, rhs2 = binops[1]

        # Check if second binop uses result of first
        if op1 == "mul" and op2 == "add" and (lhs2 == dst1 or rhs2 == dst1):
            mul_lhs_arg = arg_slots.get(lhs1)
            mul_rhs_arg = arg_slots.get(rhs1)

            # The add operand that isn't the mul result
            add_other_slot = rhs2 if lhs2 == dst1 else lhs2
            add_other_arg = arg_slots.get(add_other_slot)

            if (mul_lhs_arg is not None and mul_rhs_arg is not None
                    and add_other_arg is not None):
                # Use NumPy for FMA (a * b + c) — reliable and BLAS-accelerated
                def _fast_fma(inputs, _ml=mul_lhs_arg, _mr=mul_rhs_arg, _ao=add_other_arg):
                    a = inputs[_ml]
                    b = inputs[_mr]
                    c = inputs[_ao]
                    if isinstance(a, DeviceArray): a = a._data
                    if isinstance(b, DeviceArray): b = b._data
                    if isinstance(c, DeviceArray): c = c._data
                    return DeviceArray._wrap(a * b + c)
                return _fast_fma

        # ── Pattern: matmul + relu (A @ B then max(result, 0)) ──
        if (op1 == "matmul" and op2 == "max"
                and (lhs2 == dst1 or rhs2 == dst1)):
            mm_lhs_arg = arg_slots.get(lhs1)
            mm_rhs_arg = arg_slots.get(rhs1)

            max_other_slot = rhs2 if lhs2 == dst1 else lhs2
            max_other_arg = arg_slots.get(max_other_slot)

            if (mm_lhs_arg is not None and mm_rhs_arg is not None
                    and max_other_arg is None):
                is_zero_const = False
                for load in loads:
                    if load[1] == max_other_slot and load[2] == 0.0:
                        is_zero_const = True
                        break

                if is_zero_const:
                    def _fast_matmul_relu(inputs, _ml=mm_lhs_arg, _mr=mm_rhs_arg):
                        # Try native matmul first
                        result, used_jit = _try_jit_native("matmul", inputs[:2], allocator, None)
                        if used_jit:
                            # Apply relu on top
                            return DeviceArray._wrap(np.maximum(result._data, 0))
                        # Fallback
                        result = np.matmul(inputs[_ml], inputs[_mr])
                        return DeviceArray._wrap(np.maximum(result, 0))
                    return _fast_matmul_relu

    # ── Pattern: binop with one constant ──
    if len(binops) == 1 and len(loads) == 1 and len(unops) == 0:
        _, dst, op, lhs, rhs = binops[0]
        fn = _BINOP_DISPATCH.get(op)
        if fn is None:
            return None

        _, const_slot, const_val = loads[0]

        if lhs == const_slot and rhs in arg_slots:
            def _fast_binop_const_l(inputs, _fn=fn, _cv=const_val, _ra=arg_slots[rhs]):
                return DeviceArray._wrap(_fn(_cv, inputs[_ra]))
            return _fast_binop_const_l
        elif rhs == const_slot and lhs in arg_slots:
            def _fast_binop_const_r(inputs, _fn=fn, _cv=const_val, _la=arg_slots[lhs]):
                return DeviceArray._wrap(_fn(inputs[_la], _cv))
            return _fast_binop_const_r

    return None


def _build_arg_slot_map(allocator):
    """Build a mapping from slot index -> argument index."""
    arg_slots = {}
    for slot, tv in allocator._slots.items():
        if tv.name.startswith("arg"):
            try:
                arg_slots[slot] = int(tv.name[3:])
            except ValueError:
                pass
    return arg_slots


def interpret_trace(
    trace: List[Tuple],
    inputs: List[np.ndarray],
    allocator: SlotAllocator,
) -> Any:
    """Interpret an instruction trace on concrete NumPy arrays.

    Args:
        trace: List of instruction tuples from the tracer.
        inputs: Concrete input arrays.
        allocator: The slot allocator from tracing.

    Returns:
        The result as a DeviceArray.
    """
    slots: Dict[int, Any] = {}
    slots_get = slots.get
    binop_dispatch = _BINOP_DISPATCH
    unop_dispatch = _UNOP_DISPATCH

    # Build arg-slot mapping once
    arg_slot_map = {}
    for slot, tv in allocator._slots.items():
        if tv.name.startswith("arg"):
            try:
                arg_slot_map[int(tv.name[3:])] = slot
            except ValueError:
                pass

    # Load input arrays into their slots
    for i, arr in enumerate(inputs):
        if isinstance(arr, DeviceArray):
            arr = arr._data
        elif not isinstance(arr, np.ndarray):
            arr = np.array(arr, dtype=np.float64)
        s = arg_slot_map.get(i)
        if s is not None:
            slots[s] = arr

    # Execute each instruction
    for instr in trace:
        op = instr[0]

        if op == "binop":
            _, dst, binop, lhs, rhs = instr
            fn = binop_dispatch.get(binop)
            if fn is None:
                raise CompilationError(f"Unknown binop: {binop}")
            slots[dst] = fn(slots_get(lhs, 0), slots_get(rhs, 0))
        elif op == "load_f64":
            slots[instr[1]] = np.float64(instr[2])
        elif op == "load_f32":
            slots[instr[1]] = np.float32(instr[2])
        elif op == "load_i64":
            slots[instr[1]] = np.int64(instr[2])
        elif op == "load_i32":
            slots[instr[1]] = np.int32(instr[2])
        elif op == "load_bool":
            slots[instr[1]] = bool(instr[2])
        elif op == "unop":
            _, dst, unop, src = instr
            fn = unop_dispatch.get(unop)
            if fn is None:
                raise CompilationError(f"Unknown unop: {unop}")
            slots[dst] = fn(slots_get(src, 0))
        elif op == "move":
            slots[instr[1]] = slots_get(instr[2], 0)
        elif op == "store":
            slots[instr[1]] = slots_get(instr[2], 0)
        elif op == "nop":
            pass
        else:
            raise CompilationError(f"Unknown instruction: {op}")

    # Return value is in slot 0
    result = slots_get(0)
    if result is not None:
        if isinstance(result, np.ndarray):
            return DeviceArray._wrap(result)
        return result
    return None


# ── JIT decorator ────────────────────────────────────────────────────────────

class JitFunction:
    """A JIT-compiled function that enforces purity and optimizes via polyhedral engine.

    Usage::

        @symplex.jit
        def f(x, y):
            return x * y + x

        result = f(np.array([1.0, 2.0]), np.array([3.0, 4.0]))
    """

    def __init__(
        self,
        func: Callable,
        target: str = "server",
        element_type: str = "fp32",
        enable_flash_attention: bool = True,
        enable_transcendental_fusion: bool = True,
        enable_double_buffering: bool = True,
        enable_mixed_precision: bool = False,
        enable_ad: bool = False,
        specialize: bool = False,
        mcmc: bool = False,
    ):
        self._func = func
        self._target = target
        self._element_type = element_type
        self._enable_flash_attention = enable_flash_attention
        self._enable_transcendental_fusion = enable_transcendental_fusion
        self._enable_double_buffering = enable_double_buffering
        self._enable_mixed_precision = enable_mixed_precision
        self._enable_ad = enable_ad
        self._specialize = specialize
        self._mcmc = mcmc

        # MCMC policy: when mcmc=True, the compiler only compiles the
        # deterministic transition kernel, never the outer loop or RNG.
        # This is a compiler policy layer, not a separate code path.
        self._mcmc_policy = None
        if mcmc:
            self._mcmc_policy = {
                "fusion_aggressiveness": 3,    # High: fuse energy function terms
                "inlining_threshold": 3,       # High: inline inside kernel only
                "vectorization": True,         # Vectorize deterministic math
                "cache_policy": "shape_based", # Cache by input shape
                "trace_boundary": "stochastic_stop",  # Stop at stochastic ops
            }

        # Cached compilation results
        self._trace: Optional[List[Tuple]] = None
        self._allocator: Optional[SlotAllocator] = None
        self._cached_arg_shapes: Optional[Tuple] = None
        self._optimized_result: Optional[Dict] = None
        self._fast_path: Optional[Callable] = None  # Fast-path executor
        self._native_kernel_id: Optional[int] = None  # Native JIT kernel ID
        self._compile_time_ms: Optional[float] = None  # Last JIT compilation time in ms

        # Run AST purity check at decoration time
        try:
            check_purity(func)
        except ImpureFunctionError:
            raise

        # Copy metadata from the original function
        self.__name__ = func.__name__
        self.__doc__ = func.__doc__
        self.__module__ = func.__module__
        functools.update_wrapper(self, func)

    def _compile(self, *args):
        """Trace and optimize the function."""
        # Determine argument shapes and dtypes
        arg_shapes = []
        arg_dtypes = []
        for a in args:
            if isinstance(a, DeviceArray):
                arg_shapes.append(a.shape)
                arg_dtypes.append(str(a.dtype))
            elif isinstance(a, np.ndarray):
                arg_shapes.append(a.shape)
                arg_dtypes.append(str(a.dtype))
            else:
                arg_shapes.append(())
                if isinstance(a, float):
                    arg_dtypes.append("float64")
                elif isinstance(a, int):
                    arg_dtypes.append("int64")
                else:
                    arg_dtypes.append("float64")

        # Check if we need to recompile (shape changed)
        shape_key = tuple(arg_shapes)
        if self._trace is not None and self._cached_arg_shapes == shape_key:
            return  # Already compiled for these shapes

        self._do_compile(arg_shapes, arg_dtypes, shape_key)

    def _do_compile(self, arg_shapes, arg_dtypes, shape_key):
        """Internal compilation (only called on first call or shape change)."""
        compile_start = time.perf_counter()

        # Trace the function with abstract values
        self._trace, self._allocator = trace_function(
            self._func, arg_shapes, arg_dtypes
        )
        self._cached_arg_shapes = shape_key

        # Detect fast-path patterns (bypass full interpreter)
        self._fast_path = _detect_simple_pattern(self._trace, self._allocator)

        # Try to optimize via Rust engine
        try:
            from ._symplex_core import optimize_trace, optimize_specialized, serialize_instructions

            # Remap trace for Rust serialization
            rust_trace = []
            for instr in self._trace:
                if instr[0] == "binop" and instr[2] == "matmul":
                    rust_trace.append((instr[0], instr[1], "mul", instr[3], instr[4]))
                else:
                    rust_trace.append(instr)

            # Serialize the trace
            trace_bytes = serialize_instructions(rust_trace)

            # Run the polyhedral optimizer
            if self._specialize:
                self._optimized_result = optimize_specialized(
                    trace_bytes,
                    target=self._target,
                    element_type=self._element_type,
                    enable_flash_attention=self._enable_flash_attention,
                    enable_transcendental_fusion=self._enable_transcendental_fusion,
                    enable_double_buffering=self._enable_double_buffering,
                    enable_mixed_precision=self._enable_mixed_precision,
                    enable_ad=self._enable_ad,
                )
            else:
                self._optimized_result = optimize_trace(
                    trace_bytes,
                    target=self._target,
                    element_type=self._element_type,
                    enable_flash_attention=self._enable_flash_attention,
                    enable_transcendental_fusion=self._enable_transcendental_fusion,
                    enable_double_buffering=self._enable_double_buffering,
                    enable_mixed_precision=self._enable_mixed_precision,
                    enable_ad=self._enable_ad,
                )
        except ImportError:
            self._optimized_result = None

        compile_elapsed = time.perf_counter() - compile_start
        self._compile_time_ms = compile_elapsed * 1000.0
        print(f"[symplex.jit] Compiled '{self._func.__name__}' in {self._compile_time_ms:.2f} ms "
              f"(trace={len(self._trace)} instrs, shapes={shape_key})")

    def __call__(self, *args):
        """Execute the JIT-compiled function (optimized hot path)."""
        # ── Ultra-fast cached path: skip compile if already compiled ──
        if self._fast_path is not None:
            # Check if shapes match
            need_recompile = False
            if self._cached_arg_shapes is not None:
                for i, a in enumerate(args):
                    if i >= len(self._cached_arg_shapes):
                        need_recompile = True
                        break
                    s = a.shape if isinstance(a, (DeviceArray, np.ndarray)) else ()
                    if s != self._cached_arg_shapes[i]:
                        need_recompile = True
                        break
            else:
                need_recompile = True

            if not need_recompile:
                # Fast path: unwrap inputs and call directly
                inputs = []
                arg_shapes = []
                for a in args:
                    if isinstance(a, DeviceArray):
                        inputs.append(a._data)
                        arg_shapes.append(a.shape)
                    elif isinstance(a, np.ndarray):
                        inputs.append(a)
                        arg_shapes.append(a.shape)
                    else:
                        inputs.append(np.asarray(a, dtype=np.float64))
                        arg_shapes.append(())
                return self._fast_path(inputs)

        # ── Full compilation path ──
        self._compile(*args)

        # Prepare inputs — unwrap DeviceArrays to raw ndarrays for speed
        inputs = []
        for a in args:
            if isinstance(a, DeviceArray):
                inputs.append(a._data)
            elif isinstance(a, np.ndarray):
                inputs.append(a)
            else:
                inputs.append(np.array(a))

        # ── Fast-path: bypass interpreter for simple patterns ──
        if self._fast_path is not None:
            return self._fast_path(inputs)

        # ── Full interpreter path ──
        result = interpret_trace(self._trace, inputs, self._allocator)
        return result

    def lower(self, *args):
        """Lower the function to its trace representation (for inspection)."""
        self._compile(*args)
        return self._trace

    def optimize_info(self, *args):
        """Get optimization info from the Rust engine."""
        self._compile(*args)
        return self._optimized_result


def jit(
    func: Optional[Callable] = None,
    *,
    target: str = "server",
    element_type: str = "fp32",
    enable_flash_attention: bool = True,
    enable_transcendental_fusion: bool = True,
    enable_double_buffering: bool = True,
    enable_mixed_precision: bool = False,
    enable_ad: bool = False,
    specialize: bool = False,
    mcmc: bool = False,
) -> Union[JitFunction, Callable]:
    """Decorator to JIT-compile a pure function with polyhedral optimization.

    Only pure functions are allowed (like JAX). The function must:
    - Have no side effects (no print, IO, global mutation)
    - Not mutate arrays in-place (use x = x.at[idx].set(val))
    - Use only pure operations (arithmetic, numpy, symplex APIs)

    When mcmc=True, the compiler treats the function as an MCMC transition
    kernel: it only compiles the deterministic math (energy functions,
    proposal distributions), never the outer MCMC loop, RNG, or accept/reject
    control flow. This enables aggressive fusion of energy function terms
    while keeping stochastic control flow outside the JIT boundary.

    Args:
        target: Hardware target ("server", "edge", "tensor").
        element_type: Compute type ("fp32", "fp64", "fp16", "bf16", "int8", "int4").
        enable_flash_attention: Enable FlashAttention tile detection.
        enable_transcendental_fusion: Enable transcendental vectorization.
        enable_double_buffering: Enable async prefetch hints.
        enable_mixed_precision: Enable mixed-precision conversion.
        enable_ad: Enable reverse-mode automatic differentiation.
        specialize: Use the ML-specialized optimization pipeline.
        mcmc: Enable MCMC compiler policy (compiles only deterministic kernel).

    Returns:
        A JIT-compiled version of the function.

    Example::

        @symplex.jit
        def f(x, y):
            return x * y + x

        result = f(np.array([1.0, 2.0]), np.array([3.0, 4.0]))

        # MCMC mode: compile only the energy function
        @symplex.jit(mcmc=True)
        def energy(q):
            return 0.5 * (q * q).sum()
    """
    if func is not None:
        # Used as @jit without arguments
        return JitFunction(func)
    else:
        # Used as @jit(...) with arguments
        def decorator(f):
            return JitFunction(
                f,
                target=target,
                element_type=element_type,
                enable_flash_attention=enable_flash_attention,
                enable_transcendental_fusion=enable_transcendental_fusion,
                enable_double_buffering=enable_double_buffering,
                enable_mixed_precision=enable_mixed_precision,
                enable_ad=enable_ad,
                specialize=specialize,
                mcmc=mcmc,
            )
        return decorator


# ── Grad (reverse-mode AD) ───────────────────────────────────────────────────

def grad(func: Callable, *, target: str = "server", element_type: str = "fp32") -> Callable:
    """Create a gradient function using reverse-mode AD.

    The returned function computes the gradient of `func` with respect to
    its first argument.

    Args:
        func: A pure function to differentiate.
        target: Hardware target.
        element_type: Compute element type.

    Returns:
        A function that computes the gradient.

    Example::

        @symplex.jit
        def f(x):
            return (x * x).sum()

        df = symplex.grad(f)
        grad_val = df(np.array([1.0, 2.0, 3.0]))  # [2.0, 4.0, 6.0]
    """
    # Check purity
    check_purity(func)

    @functools.wraps(func)
    def grad_fn(*args):
        # Trace the function
        arg_shapes = []
        arg_dtypes = []
        for a in args:
            if isinstance(a, DeviceArray):
                arg_shapes.append(a.shape)
                arg_dtypes.append(str(a.dtype))
            elif isinstance(a, np.ndarray):
                arg_shapes.append(a.shape)
                arg_dtypes.append(str(a.dtype))
            else:
                arg_shapes.append(())
                arg_dtypes.append("float64")

        trace, allocator = trace_function(func, arg_shapes, arg_dtypes)

        # Try to construct adjoint via Rust engine
        try:
            from ._symplex_core import grad as rust_grad, serialize_instructions
            trace_bytes = serialize_instructions(trace)
            result = rust_grad(trace_bytes, target=target, element_type=element_type)

            if result.get("success", False):
                pass  # Fall back to numerical for now
        except ImportError:
            pass

        # Fallback: numerical gradient (central differences)
        eps = 1e-4
        inputs = []
        for a in args:
            if isinstance(a, DeviceArray):
                inputs.append(a.to_numpy().copy())
            elif isinstance(a, np.ndarray):
                inputs.append(a.copy())
            else:
                inputs.append(np.array(a, dtype=np.float64))

        # Compute numerical gradient w.r.t. first argument
        x = inputs[0].astype(np.float64)
        grad_result = np.zeros_like(x)

        it = np.nditer(x, flags=["multi_index"])
        while not it.finished:
            idx = it.multi_index
            old_val = x[idx]

            x[idx] = old_val + eps
            f_plus = func(DeviceArray(x), *inputs[1:])
            if isinstance(f_plus, DeviceArray):
                f_plus = float(f_plus.to_numpy().sum())
            elif isinstance(f_plus, np.ndarray):
                f_plus = float(f_plus.sum())
            else:
                f_plus = float(f_plus)

            x[idx] = old_val - eps
            f_minus = func(DeviceArray(x), *inputs[1:])
            if isinstance(f_minus, DeviceArray):
                f_minus = float(f_minus.to_numpy().sum())
            elif isinstance(f_minus, np.ndarray):
                f_minus = float(f_minus.sum())
            else:
                f_minus = float(f_minus)

            grad_result[idx] = (f_plus - f_minus) / (2 * eps)
            x[idx] = old_val
            it.iternext()

        return DeviceArray(grad_result)

    return grad_fn
